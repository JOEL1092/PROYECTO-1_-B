﻿//Proyecto 1 - Pensamiento computacional
//Grupo: Los pollos hermanos
//Integrantes: Kevin Joel Atz Amaya - 2001025
//             Boris Sebastian Aguilar Quiroa 
using System;

class Programa
{
    static void Main()
    {
        // Mensaje de Bienvenida 
        Console.WriteLine("Bienvenido a bordo, capitán. Me alegra tenerlo de vuelta. ¿Podrías recordarme tu nombre?");
        string nombre = Console.ReadLine();
        Console.WriteLine($"{nombre}, eres el comandante de una nave estelar de élite, enviado en una misión que definirá el destino de la civilización.");
        Console.WriteLine("Sin embargo, lo desconocido guarda en las sombras: planetas desconocidos, anomalías cósmicas, razas alienígenas.");
        Console.WriteLine("Cada decisión que tomes marcará la diferencia entre la gloria y la aniquilación.\n");
        Console.ReadKey();

        // Variables de recursos
        int combustible = 30;
        int oxigeno = 50;
        int suministros = 40;
        int integridad = 100;
        int dia = 1;

        Random random = new Random();

        // Bucle del juego que se repite hasta que se llegue al día 10 o los recursos lleguen a 0
        while (oxigeno >= 0 && integridad >= 0 && combustible >= 0 && suministros >= 0 && dia <= 10)
        {
            Console.Clear();
            Console.WriteLine($"--- Día {dia} ---");
            Console.WriteLine($"Combustible: {combustible}");
            Console.WriteLine($"Oxígeno: {oxigeno}");
            Console.WriteLine($"Suministros: {suministros}");
            Console.WriteLine($"Integridad de la nave: {integridad}%");

            // Menú de acciones
            string accion = "";
            // Bucle hasta que se cumpla la condicion de alguno de los numeros validos
            while (accion != "1" && accion != "2" && accion != "3" && accion != "4")
            {
                Console.WriteLine("\n¿Qué desea hacer hoy?");
                Console.WriteLine("1. Explorar un planeta cercano");
                Console.WriteLine("2. Reparar la nave");
                Console.WriteLine("3. Enviar señales");
                Console.WriteLine("4. Rendirse");
                Console.Write("Ingrese el número de la acción: ");
                accion = Console.ReadLine();
                if (accion != "1" && accion != "2" && accion != "3" && accion != "4")
                {
                    Console.WriteLine("Entrada no válida. Intente nuevamente.");
                }
            }

            switch (accion)
            {
                case "1": // Explorar un planeta
                    if (combustible < 15)//comprobar si hays suficiente combustible para realizar la accion
                    {
                        Console.WriteLine("No tienes suficiente combustible para explorar.");
                    }
                    else
                    {
                        combustible -= 15;// se resta la cantidad de combustible
                        Console.WriteLine("Explorando planeta cercano...");

                        // Posibles casos que se pueden dar si se explora el planeta

                        if (random.NextDouble() < 0.6)//probabilidad del 60% de encontrar oxigeno
                        {
                            int encontrado = random.Next(20, 41);// numero random de oxigeno entre 20 y 40
                            oxigeno += encontrado;
                            Console.WriteLine($"¡Encontraste {encontrado} unidades de oxígeno!");
                        }
                        if (random.NextDouble() < 0.25)// probabilidad 25% de encontrar combustible
                        {
                            int encontrado = random.Next(10, 31);// numero random de combustible entre 10 y 30
                            combustible += encontrado;
                            Console.WriteLine($"¡Encontraste {encontrado} unidades de combustible!");
                        }
                        if (random.NextDouble() < 0.5)// probabilidad del 50% de encontrar suministros
                        {
                            int encontrado = random.Next(30, 101);// numero random de suministros entre 30 y 100
                            suministros += encontrado;
                            Console.WriteLine($"¡Encontraste {encontrado} unidades de suministros!");
                        }
                        if (random.NextDouble() < 0.25)// probabilidad del 25% de encontrar una tormenta electrica
                        {
                            int daño = random.Next(10, 21);// numero random de daño entre 10 y 20 
                            integridad -= daño;
                            Console.WriteLine($"¡Tormenta eléctrica! Daño: {daño}%");
                        }
                        if (random.NextDouble() < 0.25)// probabilidad del 25% de realizar un aterrizaje forzado
                        {
                            int daño = random.Next(10, 21);// numero random de daño entre 10 y 20 
                            integridad -= daño;
                            Console.WriteLine($"¡Aterrizaje forzado! Daño: {daño}%");
                        }
                    }
                    break;

                case "2": // Reparar la nave
                    if (suministros < 10)// comprobar si se tienen suministros
                    {
                        Console.WriteLine("No tienes suficientes suministros.");
                    }
                    else
                    {
                        Console.Write("¿Cuánto porcentaje quieres reparar? ");
                        string entrada = Console.ReadLine();
                        int porcentaje;

                        // Comprobar si el numero ingresado es valido
                        if (!int.TryParse(entrada, out porcentaje) || porcentaje <= 0)
                        {
                            Console.WriteLine("Entrada inválida.");
                        }
                        else if (integridad + porcentaje > 100)// Se condiciona la cantidad de integridad
                        {
                            Console.WriteLine("La integridad no puede superar 100%.");
                        }
                        else
                        {
                            int costo = porcentaje * 10;
                            if (suministros >= costo)//comprobar si hay suficientes suministros para el porcentaje solicitado
                            {
                                suministros -= costo;
                                integridad += porcentaje;
                                Console.WriteLine($"Nave reparada en {porcentaje}%. Nueva integridad: {integridad}%");
                            }
                            else
                            {
                                Console.WriteLine("No tienes suficientes suministros.");
                            }
                        }
                    }
                    break;

                case "3": // Enviar señales
                    Console.WriteLine("Enviando señales...");
                    if (random.NextDouble() < 0.5)//probabilidad del 50% de recibir ayuda
                    {
                        combustible += 60;
                        Console.WriteLine("¡Recibiste ayuda! +60 de combustible.");
                    }
                    else // probabilidad del 50% de ser atacados
                    {
                        integridad -= 15;
                        suministros -= 20;
                        Console.WriteLine("¡Piratas espaciales! -15% integridad, -20 suministros.");
                    }
                    break;

                case "4": // Rendirse
                    Console.WriteLine("El Capitán ha abandonado la misión.");
                    Environment.Exit(0);
                    break;
            }

            // Evento nocturno especial
            Console.WriteLine("\nYa es de noche, ten cuidado con la oscuridad y el vacío del espacio. NADIE TE OIRÁ GRITAR...");
            oxigeno -= 20;
            suministros -= 30;
            Console.WriteLine("-20 oxígeno y -30 suministros por la noche.");

            // Evento aleatorio nocturno
            int evento = random.Next(1, 101);
            if (evento <= 15)//15% de probabilidad de que ocurra una tormenta cosmica
            {
                Console.WriteLine("¡Tormenta cósmica! -10 oxígeno.");
                oxigeno -= 10;
            }
            else if (evento <= 30)//15% de probabilidad de encontrar alienigena
            {
                Console.WriteLine("Se detecta vida alienígena...");
                int alien = random.Next(1, 101);
                if (alien <= 50)
                {
                    Console.WriteLine("¡Son amistosos! +20 combustible.");
                    combustible += 20;
                }
                else
                {
                    Console.WriteLine("¡Nos atacan! -10% integridad.");
                    integridad -= 10;
                }
            }
            else if (evento <= 45)//15% de probabilidad de toparse con meteoritos
            {
               // acciones que se pueden tomar si hay meteoritos 
                Console.WriteLine("¡Meteoritos a la vista!");
                Console.WriteLine("1) Maniobrar (pierdes combustible)");
                Console.WriteLine("2) Recibir impacto (pierdes integridad)");
                int eleccion = int.Parse(Console.ReadLine());
                switch (eleccion)
                {
                    case 1:
                    int perdido = random.Next(10, 31);// numero random de combustible perdido entre 10 y 30
                    combustible -= perdido;
                    Console.WriteLine($"Maniobra exitosa, pero perdiste {perdido} de combustible.");
                    break;

                    case 2:
                    int daño = random.Next(10, 31);// numero random de daño recibido entre 10 y 30
                    integridad -= daño;
                    Console.WriteLine($"Impacto recibido. Integridad -{daño}%.");
                    break;

                    default:
                    Console.WriteLine("Opción inválida. Los meteoritos dañaron la nave.");
                    integridad -= 20;
                    break;
                }
            }
            else
            {
                Console.WriteLine("La noche está tranquila, puedes descansar.");
            }

            // Estadísticas al final del día
            Console.WriteLine($"Estado al final del día {dia}:");
            Console.WriteLine($"Combustible: {combustible}");
            Console.WriteLine($"Oxígeno: {oxigeno}");
            Console.WriteLine($"Suministros: {suministros}");
            Console.WriteLine($"Integridad: {integridad}%");
            Console.ReadKey();

            dia++;
        }

        // Mensajes de fin del juego en los distintos casos 
        Console.Clear();
        Console.WriteLine("\n--- FIN DEL JUEGO ---");
        if (dia == 10)
        {
            Console.WriteLine("¡Misión completada! Has sobrevivido 10 días y llegado a tu destino.");
        }
        else if (oxigeno <= 0)
        {
            Console.WriteLine("Te has quedado sin oxígeno...");
        }
        else if (suministros <= 0)
        {
            Console.WriteLine("Te has quedado sin suministros...");
        }
        else if (combustible <= 0)
        {
            Console.WriteLine("Te has quedado sin combustible...");
        }
        else if (integridad <= 0)
        {
            Console.WriteLine("La nave ha sido destruida...");
        }
      
    }
}
